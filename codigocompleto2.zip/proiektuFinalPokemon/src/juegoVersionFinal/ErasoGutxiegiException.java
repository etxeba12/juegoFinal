package juegoVersionFinal;

public class ErasoGutxiegiException extends Exception {
	//Eraikitzaile
	public ErasoGutxiegiException() {
		super();
	}
	//gainontzeko metodoak
	public void mezuaInprimatu() {
		System.out.println("-----------------------------------------");
		System.out.println("pokemon-a eraso indizea gehiegi jaitsi du");
		System.out.println("-----------------------------------------");
	}
}
