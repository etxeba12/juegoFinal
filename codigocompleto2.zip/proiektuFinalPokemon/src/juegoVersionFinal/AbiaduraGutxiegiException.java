package juegoVersionFinal;

public class AbiaduraGutxiegiException extends Exception {
	//Eraikitzaile
	public AbiaduraGutxiegiException() {
		super();
	}
	//gainontzeko metodoak
	public void mezuaInprimatu() {
		System.out.println("--------------------------------------------");
		System.out.println("pokemon-a abiadura indizea gehiegi jaitsi du");
		System.out.println("--------------------------------------------");
	}
}
