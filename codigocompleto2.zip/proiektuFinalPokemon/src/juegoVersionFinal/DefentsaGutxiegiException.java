package juegoVersionFinal;

public class DefentsaGutxiegiException extends Exception {
	//Eraikitzaile
	public DefentsaGutxiegiException() {
		super();
	}
	//gainontzeko metodoak
	public void mezuaInprimatu() {
		System.out.println("--------------------------------------------");
		System.out.println("pokemon-a defentsa indizea gehiegi jaitsi du");
		System.out.println("--------------------------------------------");
	}
}
